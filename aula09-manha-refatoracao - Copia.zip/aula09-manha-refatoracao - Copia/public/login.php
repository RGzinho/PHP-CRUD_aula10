<?php
session_start();
require __DIR__ .'/../app/functions.php';
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $user = htmlspecialchars(trim($_POST['usuario'])) ?? '';
    $pass = htmlspecialchars(trim($_POST['senha'])) ?? '';

    if (findUser($user, $pass)) {
        $_SESSION['logado'] = true;
        $_SESSION['username'] = $user;
        header("Location: ../index.php");
        exit;
    } else {
        $_SESSION['Error'] = 'usuário ou senha inválidos';
        header("Location: formLogin.php");
        exit;
    }
}