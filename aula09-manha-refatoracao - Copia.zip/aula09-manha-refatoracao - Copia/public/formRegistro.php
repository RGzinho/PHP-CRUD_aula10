<?php
session_start();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar-se</title>
    <script src="js/validacao.js"></script>
    <link rel="stylesheet" href="./css/global.css">
</head>
<body>
    <a href="../index.php">Início</a><br>

    <h1>Insira seus dados</h1>

    <form action="registroUser.php" method="post" onsubmit="return validar2()">
        <input type="text" name="nome" placeholder="Nome"><br><br>
        <input type="password" name="senha" placeholder="Insira a sua senha"><br><br>
        <input type="submit" value="Cadastrar">
    </form>

</body>
</html>