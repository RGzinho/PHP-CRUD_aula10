<?php
session_start();

require "../app/functions.php";

$dataFile = "../app/users.json";
$itens = loadJson($dataFile);

if ($_SERVER['REQUEST_METHOD'] == "POST") {

    $nome = tratamento($_POST['nome']);
    $senha = trim($_POST['senha']);
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

    if (!isset($nome) || !isset($senha) || empty($nome)  || empty($senha)) {
        $_SESSION['erro'] = "Preencha todos os campos";
        header("Location: formRegistro.php");
        exit;
    }

    $novo = [
        "username" => $nome,
        "password" => $senha_hash
    ];

    $itens[] = $novo;
    saveJson($dataFile, $itens);

    header('Location: formLogin.php');
    exit;
}